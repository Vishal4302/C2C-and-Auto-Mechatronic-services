const createFooter =() => {
    let footer = document.querySelector('footer');

    footer.innerHTML=`
    <div class="footer-content">
    <img src="image/logo.png" class="logo" alt="logo">
  </div>
   <p class="info">support emails - help@gmail.com,
    customersupport@gmail.com</p>
    <p class="info">telephone - 9876543210, 9753124680</p>
    <div class="footer-social-container">
      <div>
        <a href="#" class="social-links">terms & services</a>
        <a href="#" class="social-links">privacy policy</a>
      </div>
      <div>
        <a href="#" class="social-links">Instagram</a>
        <a href="#" class="social-links">Facebook</a>
      </div>
    </div>
    <p class="footer-credit">C2C and Auto mechtronic services</p>

    `;
}

createFooter();
