createNav();

//toggle

let subMenu = document.getElementById("subMenu");
      
        function toggleMenu(){
          subMenu.classList.toggle("open-menu");
        }

//Search box

const searchBtn = document.querySelector('.search-btn');
const searchBox = document.querySelector('.search-box');
searchBtn.addEventListener('click', () => {
  if(searchBox.value.length){
    location.herf = 'search.html';
  }
})
