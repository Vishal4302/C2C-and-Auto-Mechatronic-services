from django import forms
from .models import Sales, Service, Job

class SaleForm(forms.ModelForm):
    class Meta:
        model = Sales
        fields = ['product','name', 'category', 'address', 'shortdescription', 'description1', 'description2', 'description3', 'image_main', 'price','mobilenum']

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ['oname','address','phnum','district','pin','pname','mname','defect']

class JobForm(forms.ModelForm):
    class Meta:
        model = Job
        fields = ['name1','address','pnum','citi','dob','gender','cv', 'iden', 'sum']
        