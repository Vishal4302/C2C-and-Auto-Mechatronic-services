from django.contrib import admin
from Shop.models import Sales, Service, Job

# Register your models here.

admin.site.register(Sales)
admin.site.register(Service)
admin.site.register(Job)

